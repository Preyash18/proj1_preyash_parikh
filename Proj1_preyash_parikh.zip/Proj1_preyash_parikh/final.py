import copy
import numpy as np

new_list = []
nodes = []
back = []
list_i = []

print("Enter number from 0-8 only, no repetition allowed:")
for i in range(3):
    a = []
    for j in range(3):
        a.append(int(input()))
    list_i.append(a)


#list_i = [[8, 1, 2], [0, 4, 3], [7, 6, 5]]
nodes.append(list_i)


def blanktilelocation(list):
    for i in range(0, 3):
        for j in range(0, 3):
            if list[i][j] == 0:
                return [i, j]


def actionleft(list):
    [x, y] = blanktilelocation(list)
    new_list = copy.deepcopy(list)
    if y != 0:
        change = new_list[x][y]
        new_list[x][y] = new_list[x][y - 1]
        new_list[x][y - 1] = change
    return new_list


def actionright(list):
    [x, y] = blanktilelocation(list)
    new_list = copy.deepcopy(list)
    if y != 2:
        change = new_list[x][y]
        new_list[x][y] = new_list[x][y + 1]
        new_list[x][y + 1] = change
    return new_list


def actiontop(list):
    [x, y] = blanktilelocation(list)
    new_list = copy.deepcopy(list)
    if x != 0:
        change = new_list[x][y]
        new_list[x][y] = new_list[x - 1][y]
        new_list[x - 1][y] = change
    return new_list


def actiondown(list):
    [x, y] = blanktilelocation(list)
    new_list = copy.deepcopy(list)
    if x != 2:
        change = new_list[x][y]
        new_list[x][y] = new_list[x + 1][y]
        new_list[x + 1][y] = change
    return new_list

def check_solvable():
    list_1d = []  # for breaking list of list into list
    for sublist in list_i:
        for item in sublist:
            list_1d.append(item)
    inverse_count = 0        #initialising inversion counter
    for i in range(9):       #for checking if puzzle is solvable or not
        if list_1d[i] == 0:
            pass
        else:
            sit = list_1d[i]
            for o in range(i+1, 9):
                if sit < list_1d[o] or list_1d[o] == 0:
                    continue
                else:
                    inverse_count += 1
    if inverse_count % 2 == 0:
        return True
    else:
        return False

def execute_main_code():
    for h in nodes:
        new_list_left = actionleft(h)
        if new_list_left in nodes:
            pass
        else:
            nodes.append(new_list_left)
            back.append([nodes.index(new_list_left), nodes.index(h)])
        if new_list_left == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Puzzle Solved!")
            break

        new_list_right = actionright(h)
        if new_list_right in nodes:
            pass
        else:
            nodes.append(new_list_right)
            back.append([nodes.index(new_list_right), nodes.index(h)])
        if new_list_right == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Puzzle Solved!")
            break

        new_list_top = actiontop(h)
        if new_list_top in nodes:
            pass
        else:
            nodes.append(new_list_top)
            back.append([nodes.index(new_list_top), nodes.index(h)])
        if new_list_top == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Puzzle Solved!")
            break

        new_list_down = actiondown(h)
        if new_list_down in nodes:
            pass
        else:
            nodes.append(new_list_down)
            back.append([nodes.index(new_list_down), nodes.index(h)])
        if new_list_down == [[1, 2, 3], [4, 5, 6], [7, 8, 0]]:
            print("Puzzle Solved!")
            break

    def back_tracking(back):
        list_for_back_tracking = []  # for breaking list of list into list
        for sublist in back:
            for item in sublist:
                list_for_back_tracking.append(item)

        dict = {list_for_back_tracking[i]: list_for_back_tracking[i + 1] for i in range(0, len(list_for_back_tracking), 2)}     #converting list into dictionary
        last_ele = back[-1][0]     #node state of solution
        y = last_ele
        back_track = []
        solution_nodes = []  # matrix containing nodes of final solution
        while y != 0:
            back_track.append([y, dict[y]])      #appending list of indexes nodes and corresponding parent nodes into list
            solution_nodes.append(nodes[y])   #appending corresponding node states into solution nodes list
            y = dict[y]

        solution_nodes.append(list_i)
        return list(reversed(back_track)), list(reversed(solution_nodes))      #returning list of solution from start position to end position


    m, n = back_tracking(back)

    # for generating output text files
    MyFile1 = open('nodePath.txt', 'w')
    for element in n:
        for i in range(0, 3):
            for j in range(0, 3):
                MyFile1.write(str(element[j][i]) + " ")
        MyFile1.write('\n')                              #for creating nodePath.txt file

    MyFile1.close()

    MyFile2 = open('NodesInfo.txt', 'w')
    for element in m:
        for i in range(0, 2):
            MyFile2.write(str(element[i]) + " ")
        MyFile2.write('\n')                              #for creating NodesInfo.txt file

    MyFile2.close()

    MyFile3 = open('Nodes.txt', 'w')
    for element in nodes:
        for i in range(0, 3):
            for j in range(0, 3):
                MyFile3.write(str(element[j][i]) + " ")
        MyFile3.write('\n')                              #for creating Nodes.txt file

    MyFile3.close()


if check_solvable() == True:
    execute_main_code()
else:
    print("Puzzle not solvable")